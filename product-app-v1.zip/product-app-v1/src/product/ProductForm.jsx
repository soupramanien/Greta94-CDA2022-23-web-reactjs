import React from "react";

export default class ProductForm extends React.Component {
    render() {
        return <h1>Formulaire d'ajout de produit</h1>
    }
}