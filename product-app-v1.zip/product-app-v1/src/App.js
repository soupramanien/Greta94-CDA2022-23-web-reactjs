import './App.css';
import ProductDisplay
  from './product/ProductDisplay';

function App() {
  return (
    <ProductDisplay />
  );
}

export default App;
